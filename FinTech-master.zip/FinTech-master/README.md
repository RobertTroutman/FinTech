# FinTech
This is a practice repository

My name is Robert Troutman. I have and BSBA in Finance/Accounting
My career goals are to secure a financial analyst position with one of the big banks
I gelt FinTech would help expand my skills needed for certain financial positions.
